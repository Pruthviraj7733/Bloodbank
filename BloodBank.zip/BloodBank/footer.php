<head>
	<style>
		.pruthvi{
    
    border-top: solid 1px;
    background: rgba(150, 150, 150, 0.5);
    width: 100%;
    height: 40px;
    padding-top: 10px;
   margin-top:50px;
    position: relative;
    bottom: 0;
    left: 0;
    text-align: center;
}
	</style>
</head>





<footer class="pruthvi">
	© Copyright <span id="demo"></span> <span class="">Blood Bank. </span> All Rights Reserved.
	<script>
		date = new Date();
    	document.getElementById("demo").innerHTML=date.getFullYear();
    </script>
</footer>
